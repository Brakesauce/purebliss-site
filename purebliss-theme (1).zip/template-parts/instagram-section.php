<?php
/* Displays Instagram-inspired lifestyle gallery */
?>
<section class="instagram-strip">
  <h2>Follow Us @drinkpurebliss</h2>
  <div class="instagram-gallery">
    <img src="https://via.placeholder.com/200x200/FFE8B5/000?text=Beach1" alt="lifestyle 1">
    <img src="https://via.placeholder.com/200x200/FFC4A3/000?text=Beach2" alt="lifestyle 2">
    <img src="https://via.placeholder.com/200x200/C3EAFD/000?text=Beach3" alt="lifestyle 3">
    <img src="https://via.placeholder.com/200x200/FDE3E3/000?text=Beach4" alt="lifestyle 4">
  </div>
</section>